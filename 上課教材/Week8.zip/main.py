import module

module.myprint()