import os
os.chdir(os.path.dirname(__file__))

from PyQt5 import QtWidgets, uic
Ui_MainWindow, QtBaseClass = uic.loadUiType('MainForm.ui')

import sys

class MainUi(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_MainWindow.__init__(self)
        self.setupUi(self)


if __name__ == "__main__":
    def run_app():
        app = QtWidgets.QApplication(sys.argv)
        window = MainUi()
        window.show()
        app.exec_()
    run_app()
    
    